const cars = [
  {
    regNo: "221-KK-1234",
    make: "Toyota",
    model: "Corolla",
    colour: "Red",
  },
  {
    regNo: "211-WD-234",
    make: "Tesla",
    model: "Model 3",
    colour: "Blue",
  },
  {
    regNo: "242-KK-999",
    make: "Toyota",
    model: "C-HR",
    colour: "Blue",
  },
];

const table = document.querySelector("table");


const displayRecs = () => {
  table.textContent = "";
  if (cars.length > 0) {
   table.insertAdjacentHTML(
    "beforeend",
    `<tr><th>Make</th><th>Model</th><th>Colour</th></tr>`
   );
   cars.forEach((car) => {
    table.insertAdjacentHTML(
      "beforeend",
      `<tr><td>${car.make}</td><td>${car.model}</td><td>${car.colour}</td>
	       <td><button data-id = ${car.regNo} >Delete</button></tr>`	   
    );
   });
      
  }
};


table.addEventListener("click", (evt) => {
  if (evt.target.matches("button")) {
    deleteRec = cars.findIndex((car) => car.regNo === evt.target.dataset.id);
    cars.splice(deleteRec, 1);
    displayRecs();
  }
});

displayRecs();




